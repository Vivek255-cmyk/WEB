<?php
session_start();
require_once 'config.php';

// Initialize variables
$error = '';
$job = null;
$has_applied = false;

try {
    // Check if job ID is provided
    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        throw new Exception("Invalid job ID.");
    }

    $job_id = $_GET['id'];

    // Get job details with company information
    $query = "SELECT j.*, c.name as company_name, c.industry, c.location as company_location, 
                     c.website, c.description as company_description 
              FROM jobs j
              JOIN company_profiles c ON j.company_id = c.id
              WHERE j.id = ?";

    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        throw new Exception("Error preparing statement: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "i", $job_id);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing statement: " . mysqli_stmt_error($stmt));
    }

    $result = mysqli_stmt_get_result($stmt);
    $job = mysqli_fetch_assoc($result);

    if (!$job) {
        throw new Exception("Job not found.");
    }

    // Check if student has already applied
    if (isset($_SESSION['user_id']) && $_SESSION['user_type'] == 'student') {
        $query = "SELECT * FROM applications WHERE job_id = ? AND student_id = (
                    SELECT id FROM student_profiles WHERE user_id = ?
                 )";
        
        $stmt = mysqli_prepare($conn, $query);
        if (!$stmt) {
            throw new Exception("Error preparing statement: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "ii", $job_id, $_SESSION['user_id']);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $has_applied = mysqli_fetch_assoc($result) ? true : false;
    }

} catch (Exception $e) {
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $job ? htmlspecialchars($job['title']) : 'Job Details'; ?> - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .navbar {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
        }
        .job-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .company-section {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
        }
        .badge-custom {
            font-size: 0.9rem;
            padding: 0.5rem 1rem;
            border-radius: 10px;
            margin-right: 0.5rem;
        }
        .btn-apply {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
            border: none;
            padding: 10px 30px;
            border-radius: 10px;
            color: white;
            transition: transform 0.3s ease;
        }
        .btn-apply:hover {
            transform: translateY(-3px);
            color: white;
        }
        .btn-applied {
            background: #198754;
            color: white;
        }
        .skill-badge {
            background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
            color: white;
            margin-right: 5px;
            margin-bottom: 5px;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            display: inline-block;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">Job Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search_jobs.php">Search Jobs</a>
                    </li>
                    <?php if (isset($_SESSION['user_type'])): ?>
                        <?php if ($_SESSION['user_type'] == 'student'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="student/dashboard.php">Dashboard</a>
                            </li>
                        <?php elseif ($_SESSION['user_type'] == 'company'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="company/dashboard.php">Dashboard</a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="register.php">Register</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($error); ?>
                <br>
                <a href="search_jobs.php" class="alert-link">Back to Job Search</a>
            </div>
        <?php else: ?>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="job-card p-4">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h2><?php echo htmlspecialchars($job['title']); ?></h2>
                            <?php if (isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'student'): ?>
                                <?php if ($has_applied): ?>
                                    <button class="btn btn-applied" disabled>
                                        <i class="fas fa-check-circle me-2"></i>Applied
                                    </button>
                                <?php else: ?>
                                    <a href="apply_job.php?id=<?php echo $job['id']; ?>" class="btn btn-apply">
                                        <i class="fas fa-paper-plane me-2"></i>Apply Now
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <div class="mb-4">
                            <span class="badge badge-custom bg-primary">
                                <i class="fas fa-briefcase me-2"></i><?php echo htmlspecialchars($job['job_type']); ?>
                            </span>
                            <span class="badge badge-custom bg-secondary">
                                <i class="fas fa-map-marker-alt me-2"></i><?php echo htmlspecialchars($job['location']); ?>
                            </span>
                            <?php if ($job['required_course']): ?>
                                <span class="badge badge-custom bg-info">
                                    <i class="fas fa-graduation-cap me-2"></i><?php echo htmlspecialchars($job['required_course']); ?>
                                </span>
                            <?php endif; ?>
                            <?php if ($job['salary_range']): ?>
                                <span class="badge badge-custom bg-success">
                                    <i class="fas fa-money-bill-wave me-2"></i><?php echo htmlspecialchars($job['salary_range']); ?>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="mb-4">
                            <h5>Job Description</h5>
                            <p><?php echo nl2br(htmlspecialchars($job['description'])); ?></p>
                        </div>

                        <?php if ($job['required_skills']): ?>
                            <div class="mb-4">
                                <h5>Required Skills</h5>
                                <div>
                                    <?php foreach (explode(',', $job['required_skills']) as $skill): ?>
                                        <span class="skill-badge">
                                            <i class="fas fa-check-circle me-1"></i><?php echo htmlspecialchars(trim($skill)); ?>
                                        </span>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="mb-4">
                            <h5>Experience Level</h5>
                            <p><?php echo htmlspecialchars(ucfirst($job['experience_level'])); ?></p>
                        </div>

                        <?php if ($job['deadline_date']): ?>
                            <div class="mb-4">
                                <h5>Application Deadline</h5>
                                <p><i class="fas fa-clock me-2"></i><?php echo date('F j, Y', strtotime($job['deadline_date'])); ?></p>
                            </div>
                        <?php endif; ?>

                        <div class="company-section">
                            <h4>About the Company</h4>
                            <h5 class="mb-3"><?php echo htmlspecialchars($job['company_name']); ?></h5>
                            
                            <div class="mb-3">
                                <strong><i class="fas fa-industry me-2"></i>Industry:</strong>
                                <?php echo htmlspecialchars($job['industry']); ?>
                            </div>
                            
                            <div class="mb-3">
                                <strong><i class="fas fa-map-marker-alt me-2"></i>Location:</strong>
                                <?php echo htmlspecialchars($job['company_location']); ?>
                            </div>
                            
                            <?php if ($job['website']): ?>
                                <div class="mb-3">
                                    <strong><i class="fas fa-globe me-2"></i>Website:</strong>
                                    <a href="<?php echo htmlspecialchars($job['website']); ?>" target="_blank" rel="noopener noreferrer">
                                        <?php echo htmlspecialchars($job['website']); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($job['company_description']): ?>
                                <div class="mb-3">
                                    <strong><i class="fas fa-info-circle me-2"></i>Description:</strong>
                                    <p class="mt-2"><?php echo nl2br(htmlspecialchars($job['company_description'])); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="mt-4">
                            <a href="search_jobs.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Back to Job Search
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 