<?php
session_start();
require_once '../config.php';

// Check if user is logged in and is a company
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'company') {
    header("Location: ../index.php");
    exit();
}

// Initialize variables
$company = null;
$jobs = null;
$error = '';

try {
    // Fetch company profile
    $user_id = $_SESSION['user_id'];
    $query = "SELECT * FROM company_profiles WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    
    if (!$stmt) {
        throw new Exception("Error preparing statement: " . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing statement: " . mysqli_stmt_error($stmt));
    }
    
    $result = mysqli_stmt_get_result($stmt);
    $company = mysqli_fetch_assoc($result);

    if (!$company) {
        throw new Exception("Company profile not found. Please complete your profile first.");
    }

    // Fetch posted jobs
    $query = "SELECT * FROM jobs WHERE company_id = ? ORDER BY post_date DESC";
    $stmt = mysqli_prepare($conn, $query);
    
    if (!$stmt) {
        throw new Exception("Error preparing jobs statement: " . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($stmt, "i", $company['id']);
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing jobs statement: " . mysqli_stmt_error($stmt));
    }
    
    $jobs = mysqli_stmt_get_result($stmt);

} catch (Exception $e) {
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Dashboard - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .navbar {
            background: linear-gradient(135deg, #198754 0%, #146c43 100%);
        }
        .stats-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        .stats-card:hover {
            transform: translateY(-5px);
        }
        .job-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        .job-card:hover {
            transform: translateY(-5px);
        }
        .stats-icon {
            font-size: 2rem;
            margin-bottom: 10px;
            color: #198754;
        }
        .stats-number {
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
        }
        .stats-label {
            color: #666;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Job Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="post_job.php">Post New Job</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="view_applications.php">View Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Company Profile</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php else: ?>
            <!-- Welcome Section -->
            <div class="row mb-4">
                <div class="col-md-8">
                    <div class="stats-card">
                        <h3>Welcome, <?php echo htmlspecialchars($company['name']); ?>!</h3>
                        <p class="text-muted mb-0"><?php echo htmlspecialchars($company['industry'] ?? 'Industry not specified'); ?></p>
                        <p class="text-muted"><?php echo htmlspecialchars($company['location'] ?? 'Location not specified'); ?></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stats-card text-center">
                        <i class="fas fa-briefcase stats-icon"></i>
                        <div class="stats-number"><?php echo $jobs ? mysqli_num_rows($jobs) : 0; ?></div>
                        <div class="stats-label">Active Job Postings</div>
                    </div>
                </div>
            </div>

            <!-- Recent Job Postings -->
            <div class="row">
                <div class="col-12">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4>Recent Job Postings</h4>
                        <a href="post_job.php" class="btn btn-success">
                            <i class="fas fa-plus-circle me-2"></i>Post New Job
                        </a>
                    </div>

                    <?php if ($jobs && mysqli_num_rows($jobs) > 0): ?>
                        <?php while ($job = mysqli_fetch_assoc($jobs)): ?>
                            <div class="job-card p-4">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h5 class="mb-0"><?php echo htmlspecialchars($job['title']); ?></h5>
                                    <span class="badge bg-<?php echo $job['status'] == 'active' ? 'success' : 'secondary'; ?>">
                                        <?php echo ucfirst($job['status']); ?>
                                    </span>
                                </div>
                                <div class="mb-3">
                                    <p class="text-muted mb-2">
                                        <i class="fas fa-map-marker-alt me-2"></i><?php echo htmlspecialchars($job['location']); ?>
                                    </p>
                                    <p class="text-muted mb-2">
                                        <i class="fas fa-clock me-2"></i>Posted: <?php echo date('M d, Y', strtotime($job['post_date'])); ?>
                                    </p>
                                    <?php if ($job['deadline_date']): ?>
                                        <p class="text-muted mb-0">
                                            <i class="fas fa-calendar-alt me-2"></i>Deadline: <?php echo date('M d, Y', strtotime($job['deadline_date'])); ?>
                                        </p>
                                    <?php endif; ?>
                                </div>
                                <div class="d-flex gap-2">
                                    <a href="edit_job.php?id=<?php echo $job['id']; ?>" class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-edit me-1"></i>Edit
                                    </a>
                                    <a href="view_applications.php?job_id=<?php echo $job['id']; ?>" class="btn btn-outline-success btn-sm">
                                        <i class="fas fa-users me-1"></i>View Applications
                                    </a>
                                    <button class="btn btn-sm toggle-status-btn <?php echo $job['status'] == 'active' ? 'btn-danger' : 'btn-success'; ?>" 
                                            data-job-id="<?php echo $job['id']; ?>"
                                            data-current-status="<?php echo $job['status']; ?>">
                                        <i class="fas <?php echo $job['status'] == 'active' ? 'fa-lock' : 'fa-lock-open'; ?> me-1"></i>
                                        <?php echo $job['status'] == 'active' ? 'Close' : 'Open'; ?>
                                    </button>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>You haven't posted any jobs yet. 
                            <a href="post_job.php" class="alert-link">Post your first job</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.toggle-status-btn').click(function() {
                const btn = $(this);
                const jobId = btn.data('job-id');
                
                $.ajax({
                    url: 'toggle_job_status.php',
                    type: 'POST',
                    data: { job_id: jobId },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            // Update button appearance
                            if (response.new_status === 'active') {
                                btn.removeClass('btn-success').addClass('btn-danger');
                                btn.html('<i class="fas fa-lock me-1"></i>Close');
                            } else {
                                btn.removeClass('btn-danger').addClass('btn-success');
                                btn.html('<i class="fas fa-lock-open me-1"></i>Open');
                            }
                            
                            // Update status badge
                            const statusBadge = btn.closest('.job-card').find('.badge');
                            statusBadge.removeClass('bg-success bg-secondary')
                                     .addClass(response.new_status === 'active' ? 'bg-success' : 'bg-secondary')
                                     .text(response.new_status === 'active' ? 'Active' : 'Closed');
                        } else {
                            // Only show alert for errors
                            alert('Error: ' + response.message);
                        }
                    },
                    error: function() {
                        alert('An error occurred while updating the job status.');
                    }
                });
            });
        });
    </script>
</body>
</html> 