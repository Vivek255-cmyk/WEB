<?php
session_start();
require_once '../config.php';

// Initialize response array
$response = [
    'success' => false,
    'message' => '',
    'new_status' => ''
];

// Check if user is logged in and is a company
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    $response['message'] = 'Unauthorized access';
    echo json_encode($response);
    exit;
}

// Check if job ID is provided
if (!isset($_POST['job_id']) || !is_numeric($_POST['job_id'])) {
    $response['message'] = 'Invalid job ID';
    echo json_encode($response);
    exit;
}

try {
    $job_id = $_POST['job_id'];
    
    // First, verify that this job belongs to the logged-in company
    $verify_query = "SELECT j.* FROM jobs j 
                    JOIN company_profiles c ON j.company_id = c.id 
                    WHERE j.id = ? AND c.user_id = ?";
    
    $stmt = mysqli_prepare($conn, $verify_query);
    if (!$stmt) {
        throw new Exception("Error preparing verification statement: " . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($stmt, "ii", $job_id, $_SESSION['user_id']);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing verification: " . mysqli_stmt_error($stmt));
    }
    
    $result = mysqli_stmt_get_result($stmt);
    $job = mysqli_fetch_assoc($result);
    
    if (!$job) {
        throw new Exception("Job not found or you don't have permission to modify it");
    }
    
    // Toggle the status between 'active' and 'closed'
    $new_status = ($job['status'] == 'active') ? 'closed' : 'active';
    
    // Update the job status
    $update_query = "UPDATE jobs SET status = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $update_query);
    if (!$stmt) {
        throw new Exception("Error preparing update statement: " . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($stmt, "si", $new_status, $job_id);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error updating job status: " . mysqli_stmt_error($stmt));
    }
    
    if (mysqli_affected_rows($conn) > 0) {
        $response['success'] = true;
        $response['message'] = "Job status successfully updated to " . ucfirst($new_status);
        $response['new_status'] = $new_status;
    } else {
        throw new Exception("No changes were made to the job status");
    }
    
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response); 