<?php
session_start();
require_once 'config.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    header("Location: login.php");
    exit();
}

// Initialize variables
$error = '';
$success = '';
$job = null;

try {
    // Check if job ID is provided
    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        throw new Exception("Invalid job ID.");
    }

    $job_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];

    // Get student profile ID
    $query = "SELECT id FROM student_profiles WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        throw new Exception("Error preparing statement: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "i", $user_id);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing statement: " . mysqli_stmt_error($stmt));
    }

    $result = mysqli_stmt_get_result($stmt);
    $student = mysqli_fetch_assoc($result);

    if (!$student) {
        throw new Exception("Please complete your profile before applying.");
    }

    // Get job details
    $query = "SELECT j.*, c.name as company_name 
              FROM jobs j
              JOIN company_profiles c ON j.company_id = c.id
              WHERE j.id = ?";

    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        throw new Exception("Error preparing statement: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "i", $job_id);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing statement: " . mysqli_stmt_error($stmt));
    }

    $result = mysqli_stmt_get_result($stmt);
    $job = mysqli_fetch_assoc($result);

    if (!$job) {
        throw new Exception("Job not found.");
    }

    // Check if already applied
    $query = "SELECT * FROM applications WHERE job_id = ? AND student_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        throw new Exception("Error preparing statement: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "ii", $job_id, $student['id']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if (mysqli_fetch_assoc($result)) {
        throw new Exception("You have already applied for this job.");
    }

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $cover_letter = trim($_POST['cover_letter']);

        if (empty($cover_letter)) {
            throw new Exception("Please provide a cover letter.");
        }

        // Insert application
        $query = "INSERT INTO applications (job_id, student_id, cover_letter, application_date) 
                 VALUES (?, ?, ?, NOW())";
        
        $stmt = mysqli_prepare($conn, $query);
        if (!$stmt) {
            throw new Exception("Error preparing statement: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "iis", $job_id, $student['id'], $cover_letter);
        
        if (mysqli_stmt_execute($stmt)) {
            $success = "Application submitted successfully!";
        } else {
            throw new Exception("Error submitting application: " . mysqli_stmt_error($stmt));
        }
    }

} catch (Exception $e) {
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for Job - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .navbar {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
        }
        .apply-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .job-info {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .btn-submit {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            color: white;
            transition: transform 0.3s ease;
        }
        .btn-submit:hover {
            transform: translateY(-3px);
            color: white;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">Job Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search_jobs.php">Search Jobs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="student/dashboard.php">Dashboard</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="apply-card p-4">
                    <?php if ($error): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo htmlspecialchars($error); ?>
                            <?php if ($error == "Please complete your profile before applying."): ?>
                                <br>
                                <a href="student/profile.php" class="alert-link">Complete your profile</a>
                            <?php endif; ?>
                        </div>
                    <?php elseif ($success): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo htmlspecialchars($success); ?>
                            <br>
                            <a href="student/my_applications.php" class="alert-link">View your applications</a>
                        </div>
                    <?php else: ?>
                        <h3 class="mb-4">Apply for Job</h3>
                        
                        <div class="job-info">
                            <h4><?php echo htmlspecialchars($job['title']); ?></h4>
                            <h6 class="text-muted mb-3">
                                <i class="fas fa-building me-2"></i><?php echo htmlspecialchars($job['company_name']); ?>
                            </h6>
                            <div class="mb-3">
                                <span class="badge bg-primary me-2">
                                    <i class="fas fa-briefcase me-1"></i><?php echo htmlspecialchars($job['job_type']); ?>
                                </span>
                                <span class="badge bg-secondary">
                                    <i class="fas fa-map-marker-alt me-1"></i><?php echo htmlspecialchars($job['location']); ?>
                                </span>
                            </div>
                        </div>

                        <form method="POST">
                            <div class="mb-3">
                                <label for="cover_letter" class="form-label">Cover Letter <span class="text-danger">*</span></label>
                                <textarea class="form-control" id="cover_letter" name="cover_letter" rows="6" required></textarea>
                                <div class="form-text">Explain why you're interested in this position and what makes you a good fit.</div>
                            </div>

                            <div class="d-flex justify-content-between">
                                <a href="view_job.php?id=<?php echo $job['id']; ?>" class="btn btn-secondary">Back to Job Details</a>
                                <button type="submit" class="btn btn-submit">
                                    <i class="fas fa-paper-plane me-2"></i>Submit Application
                                </button>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 