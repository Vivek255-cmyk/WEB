<?php
session_start();
require_once 'config.php';

// Initialize variables
$error = '';
$jobs = [];
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$location = isset($_GET['location']) ? trim($_GET['location']) : '';
$job_type = isset($_GET['job_type']) ? trim($_GET['job_type']) : '';
$experience_level = isset($_GET['experience_level']) ? trim($_GET['experience_level']) : '';

try {
    // Build the base query
    $query = "SELECT j.*, c.name as company_name, c.industry 
              FROM jobs j
              JOIN company_profiles c ON j.company_id = c.id
              WHERE 1=1";
    $params = [];
    $types = "";

    // Add search conditions
    if ($search) {
        $query .= " AND (j.title LIKE ? OR j.description LIKE ? OR j.required_skills LIKE ? OR c.name LIKE ?)";
        $search_param = "%$search%";
        $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param]);
        $types .= "ssss";
    }

    if ($location) {
        $query .= " AND j.location LIKE ?";
        $params[] = "%$location%";
        $types .= "s";
    }

    if ($job_type) {
        $query .= " AND j.job_type = ?";
        $params[] = $job_type;
        $types .= "s";
    }

    if ($experience_level) {
        $query .= " AND j.experience_level = ?";
        $params[] = $experience_level;
        $types .= "s";
    }

    // Order by most recent first
    $query .= " ORDER BY j.post_date DESC";

    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        throw new Exception("Error preparing statement: " . mysqli_error($conn));
    }

    if (!empty($params)) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }

    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing statement: " . mysqli_stmt_error($stmt));
    }

    $result = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($result)) {
        $jobs[] = $row;
    }

} catch (Exception $e) {
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Jobs - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .navbar {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
        }
        .search-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .job-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        .job-card:hover {
            transform: translateY(-5px);
        }
        .badge-skill {
            background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
            color: white;
            margin-right: 5px;
            margin-bottom: 5px;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
        }
        .btn-search {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            color: white;
            transition: transform 0.3s ease;
        }
        .btn-search:hover {
            transform: translateY(-3px);
            color: white;
        }
        .btn-view {
            background: linear-gradient(135deg, #198754 0%, #146c43 100%);
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            color: white;
            transition: transform 0.3s ease;
        }
        .btn-view:hover {
            transform: translateY(-2px);
            color: white;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">Job Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="search_jobs.php">Search Jobs</a>
                    </li>
                    <?php if (isset($_SESSION['user_type'])): ?>
                        <?php if ($_SESSION['user_type'] == 'student'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="student/dashboard.php">Dashboard</a>
                            </li>
                        <?php elseif ($_SESSION['user_type'] == 'company'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="company/dashboard.php">Dashboard</a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="register.php">Register</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="search-card p-4 mb-4">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label for="search" class="form-label">Search</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" class="form-control" id="search" name="search" placeholder="Job title or description" value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <label for="location" class="form-label">Location</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                        <input type="text" class="form-control" id="location" name="location" placeholder="City or country" value="<?php echo htmlspecialchars($location); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <label for="required_course" class="form-label">Required Course</label>
                    <input type="text" class="form-control" id="required_course" name="required_course" placeholder="Required course" value="<?php echo htmlspecialchars(isset($_GET['required_course']) ? $_GET['required_course'] : ''); ?>">
                </div>
                <div class="col-md-3">
                    <label for="required_skills" class="form-label">Required Skills</label>
                    <input type="text" class="form-control" id="required_skills" name="required_skills" placeholder="Required skills" value="<?php echo htmlspecialchars(isset($_GET['required_skills']) ? $_GET['required_skills'] : ''); ?>">
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-search">
                        <i class="fas fa-search me-2"></i>Search Jobs
                    </button>
                </div>
            </form>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php else: ?>
            <?php if (empty($jobs)): ?>
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle me-2"></i>No jobs found matching your criteria.
                </div>
            <?php else: ?>
                <div class="row">
                    <?php foreach ($jobs as $job): ?>
                        <div class="col-12 mb-4">
                            <div class="job-card">
                                <div class="card-body p-4">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <h4 class="card-title mb-3"><?php echo htmlspecialchars($job['title']); ?></h4>
                                            <h6 class="text-muted mb-3">
                                                <i class="fas fa-building me-2"></i><?php echo htmlspecialchars($job['company_name']); ?>
                                            </h6>
                                            <div class="mb-3">
                                                <span class="badge bg-primary me-2">
                                                    <i class="fas fa-briefcase me-1"></i><?php echo htmlspecialchars($job['job_type']); ?>
                                                </span>
                                                <span class="badge bg-secondary me-2">
                                                    <i class="fas fa-map-marker-alt me-1"></i><?php echo htmlspecialchars($job['location']); ?>
                                                </span>
                                                <?php if ($job['salary_range']): ?>
                                                    <span class="badge bg-success">
                                                        <i class="fas fa-money-bill-wave me-1"></i><?php echo htmlspecialchars($job['salary_range']); ?>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <?php if ($job['required_skills']): ?>
                                                <div class="mb-3">
                                                    <?php foreach (explode(',', $job['required_skills']) as $skill): ?>
                                                        <span class="badge-skill"><?php echo htmlspecialchars(trim($skill)); ?></span>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                            <p class="card-text text-muted">
                                                <?php 
                                                $description = $job['description'];
                                                echo htmlspecialchars(strlen($description) > 200 ? substr($description, 0, 200) . '...' : $description); 
                                                ?>
                                            </p>
                                        </div>
                                        <div class="col-md-4 text-md-end d-flex flex-column justify-content-between">
                                            <div class="mb-3">
                                                <?php if (isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'student'): ?>
                                                    <a href="apply_job.php?id=<?php echo $job['id']; ?>" class="btn btn-primary mb-2 w-100">
                                                        <i class="fas fa-paper-plane me-2"></i>Apply Now
                                                    </a>
                                                <?php endif; ?>
                                                <a href="view_job.php?id=<?php echo $job['id']; ?>" class="btn btn-view w-100">
                                                    <i class="fas fa-eye me-2"></i>View Details
                                                </a>
                                            </div>
                                            <?php if ($job['deadline_date']): ?>
                                                <div class="text-muted">
                                                    <small>
                                                        <i class="fas fa-clock me-1"></i>
                                                        Deadline: <?php echo date('M j, Y', strtotime($job['deadline_date'])); ?>
                                                    </small>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 