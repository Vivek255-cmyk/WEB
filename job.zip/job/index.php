<?php
session_start();
if(isset($_SESSION['error'])) {
    $error = $_SESSION['error'];
    unset($_SESSION['error']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Portal - Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .login-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
        }
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
        }
        .nav-link {
            font-size: 16px;
        }
        .hero-section {
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
            color: white;
            padding: 60px 0;
            margin-bottom: 40px;
        }
        .login-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            padding: 20px;
            height: 100%;
            transition: transform 0.3s ease;
        }
        .login-card:hover {
            transform: translateY(-5px);
        }
        .login-icon {
            font-size: 36px;
            margin-bottom: 15px;
        }
        .student-icon { color: #0d6efd; }
        .company-icon { color: #198754; }
        .admin-icon { color: #dc3545; }
        .btn-student {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
            border: none;
        }
        .btn-company {
            background: linear-gradient(135deg, #198754 0%, #146c43 100%);
            border: none;
        }
        .btn-admin {
            background: linear-gradient(135deg, #dc3545 0%, #b02a37 100%);
            border: none;
        }
        .btn-student:hover, .btn-company:hover, .btn-admin:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .register-link {
            color: #6c757d;
            text-decoration: none;
            font-size: 0.9rem;
        }
        .register-link:hover {
            color: #0d6efd;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">Job Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="hero-section">
        <div class="container text-center">
            <h1>Welcome to Job Portal</h1>
            <p class="lead">Find your dream job or the perfect candidate</p>
        </div>
    </div>

    <div class="container">
        <?php if(isset($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row g-4">
            <!-- Student Login -->
            <div class="col-md-4">
                <div class="login-card">
                    <div class="text-center mb-4">
                        <i class="fas fa-user-graduate login-icon student-icon"></i>
                        <h3>Student Login</h3>
                    </div>
                    <form action="login_process.php" method="POST">
                        <input type="hidden" name="user_type" value="student">
                        <div class="mb-3">
                            <label for="student_username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="student_username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="student_password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="student_password" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-student w-100 mb-2">
                            <i class="fas fa-sign-in-alt me-2"></i>Login
                        </button>
                        <div class="text-center">
                            <a href="student/register.php" class="register-link">
                                <i class="fas fa-user-plus me-1"></i>Register as Student
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Company Login -->
            <div class="col-md-4">
                <div class="login-card">
                    <div class="text-center mb-4">
                        <i class="fas fa-building login-icon company-icon"></i>
                        <h3>Company Login</h3>
                    </div>
                    <form action="login_process.php" method="POST">
                        <input type="hidden" name="user_type" value="company">
                        <div class="mb-3">
                            <label for="company_username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="company_username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="company_password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="company_password" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-success btn-company w-100 mb-2">
                            <i class="fas fa-sign-in-alt me-2"></i>Login
                        </button>
                        <div class="text-center">
                            <a href="company/register.php" class="register-link">
                                <i class="fas fa-user-plus me-1"></i>Register as Company
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Admin Login -->
            <div class="col-md-4">
                <div class="login-card">
                    <div class="text-center mb-4">
                        <i class="fas fa-user-shield login-icon admin-icon"></i>
                        <h3>Admin Login</h3>
                    </div>
                    <form action="login_process.php" method="POST">
                        <input type="hidden" name="user_type" value="admin">
                        <div class="mb-3">
                            <label for="admin_username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="admin_username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="admin_password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="admin_password" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-danger btn-admin w-100">
                            <i class="fas fa-sign-in-alt me-2"></i>Login
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 