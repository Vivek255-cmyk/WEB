<?php
require_once 'config.php';

// Check database connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// SQL to create tables
$sql = "
-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL,
    user_type ENUM('student', 'company', 'admin') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create company_profiles table
CREATE TABLE IF NOT EXISTS company_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    industry VARCHAR(100),
    website VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Create student_profiles table
CREATE TABLE IF NOT EXISTS student_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    course VARCHAR(100) NOT NULL,
    graduation_year INT NOT NULL,
    skills TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Create jobs table
CREATE TABLE IF NOT EXISTS jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    required_skills TEXT,
    required_course VARCHAR(100),
    location VARCHAR(255),
    salary_range VARCHAR(100),
    status ENUM('active', 'closed') DEFAULT 'active',
    post_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deadline_date DATE,
    FOREIGN KEY (company_id) REFERENCES company_profiles(id)
);

-- Create applications table
CREATE TABLE IF NOT EXISTS applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    job_id INT NOT NULL,
    status ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
    apply_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES student_profiles(id),
    FOREIGN KEY (job_id) REFERENCES jobs(id)
);

-- Create interviews table
CREATE TABLE IF NOT EXISTS interviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL,
    interview_date DATETIME NOT NULL,
    interview_type ENUM('online', 'in-person', 'phone') NOT NULL,
    status ENUM('scheduled', 'completed', 'cancelled') DEFAULT 'scheduled',
    notes TEXT,
    FOREIGN KEY (application_id) REFERENCES applications(id)
);
";

// Execute SQL queries
$success = true;
$errors = [];

// Split SQL into individual queries
$queries = array_filter(array_map('trim', explode(';', $sql)));

foreach ($queries as $query) {
    if (!empty($query)) {
        if (!mysqli_query($conn, $query)) {
            $success = false;
            $errors[] = "Error executing query: " . mysqli_error($conn) . "\nQuery: " . $query;
        }
    }
}

if ($success) {
    echo "<h2>Database Setup Successful!</h2>";
    echo "<p>All tables have been created successfully.</p>";
} else {
    echo "<h2>Database Setup Completed with Errors</h2>";
    echo "<p>Some tables might not have been created. Please check the errors below:</p>";
    echo "<ul>";
    foreach ($errors as $error) {
        echo "<li>" . htmlspecialchars($error) . "</li>";
    }
    echo "</ul>";
}

// Show existing tables
echo "<h3>Existing Tables:</h3>";
$result = mysqli_query($conn, "SHOW TABLES");
if ($result) {
    echo "<ul>";
    while ($row = mysqli_fetch_row($result)) {
        echo "<li>" . $row[0] . "</li>";
    }
    echo "</ul>";
} else {
    echo "<p>Error showing tables: " . mysqli_error($conn) . "</p>";
}

// Create admin user if not exists
$username = "admin";
$email = "admin@jobportal.com";
$password = "admin123";
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$check_query = "SELECT * FROM users WHERE username = ? AND user_type = 'admin'";
$stmt = mysqli_prepare($conn, $check_query);
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {
    $insert_query = "INSERT INTO users (username, email, password, user_type) VALUES (?, ?, ?, 'admin')";
    $stmt = mysqli_prepare($conn, $insert_query);
    mysqli_stmt_bind_param($stmt, "sss", $username, $email, $hashed_password);
    
    if (mysqli_stmt_execute($stmt)) {
        echo "<h3>Admin User Created!</h3>";
        echo "<p>Default admin credentials:</p>";
        echo "<ul>";
        echo "<li>Username: " . $username . "</li>";
        echo "<li>Password: " . $password . "</li>";
        echo "<li>Email: " . $email . "</li>";
        echo "</ul>";
        echo "<p>Please change the password after first login.</p>";
    } else {
        echo "<p>Error creating admin user: " . mysqli_error($conn) . "</p>";
    }
} else {
    echo "<h3>Admin User Already Exists</h3>";
    echo "<p>An admin user with these credentials already exists in the database.</p>";
}
?> 