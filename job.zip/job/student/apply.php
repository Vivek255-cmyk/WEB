<?php
session_start();
require_once '../config.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    header("Location: ../index.php");
    exit();
}

// Check if job_id is provided
if (!isset($_GET['job_id'])) {
    header("Location: dashboard.php");
    exit();
}

$job_id = (int)$_GET['job_id'];

// Get job details
$query = "SELECT j.*, c.company_name 
          FROM jobs j 
          JOIN company_profiles c ON j.company_id = c.id 
          WHERE j.id = ? AND j.status = 'open'";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $job_id);
mysqli_stmt_execute($stmt);
$job = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$job) {
    header("Location: dashboard.php");
    exit();
}

// Get student profile
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM student_profiles WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$student = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// Check if already applied
$query = "SELECT * FROM applications WHERE job_id = ? AND student_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "ii", $job_id, $student['id']);
mysqli_stmt_execute($stmt);
$existing_application = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if ($existing_application) {
    $_SESSION['error'] = "You have already applied for this job.";
    header("Location: dashboard.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cover_letter = mysqli_real_escape_string($conn, $_POST['cover_letter']);
    
    // Handle resume upload
    $resume_path = $student['resume_path']; // Use existing resume by default
    if (isset($_FILES['resume']) && $_FILES['resume']['error'] == 0) {
        $allowed = ['pdf', 'doc', 'docx'];
        $filename = $_FILES['resume']['name'];
        $filetype = pathinfo($filename, PATHINFO_EXTENSION);
        
        if (in_array(strtolower($filetype), $allowed)) {
            $new_filename = uniqid('resume_') . '.' . $filetype;
            $upload_path = '../uploads/resumes/' . $new_filename;
            
            if (move_uploaded_file($_FILES['resume']['tmp_name'], $upload_path)) {
                $resume_path = 'uploads/resumes/' . $new_filename;
                
                // Update student profile with new resume
                $query = "UPDATE student_profiles SET resume_path = ? WHERE id = ?";
                $stmt = mysqli_prepare($conn, $query);
                mysqli_stmt_bind_param($stmt, "si", $resume_path, $student['id']);
                mysqli_stmt_execute($stmt);
            }
        }
    }

    // Create application
    $query = "INSERT INTO applications (job_id, student_id, cover_letter) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "iis", $job_id, $student['id'], $cover_letter);
    
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "Application submitted successfully!";
        header("Location: dashboard.php");
        exit();
    } else {
        $_SESSION['error'] = "Error submitting application. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for Job - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Job Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="my_applications.php">My Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-body">
                        <h2 class="card-title">Apply for <?php echo htmlspecialchars($job['title']); ?></h2>
                        <h6 class="card-subtitle mb-3 text-muted"><?php echo htmlspecialchars($job['company_name']); ?></h6>
                        
                        <?php
                        if (isset($_SESSION['error'])) {
                            echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
                            unset($_SESSION['error']);
                        }
                        ?>

                        <div class="mb-4">
                            <h5>Job Details</h5>
                            <p><?php echo nl2br(htmlspecialchars($job['description'])); ?></p>
                            <p><strong>Requirements:</strong><br><?php echo nl2br(htmlspecialchars($job['requirements'])); ?></p>
                            <p><strong>Location:</strong> <?php echo htmlspecialchars($job['location']); ?></p>
                            <p><strong>Salary Range:</strong> <?php echo htmlspecialchars($job['salary_range']); ?></p>
                            <p><strong>Application Deadline:</strong> <?php echo htmlspecialchars($job['deadline_date']); ?></p>
                        </div>

                        <form method="POST" action="" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="cover_letter" class="form-label">Cover Letter</label>
                                <textarea class="form-control" id="cover_letter" name="cover_letter" rows="6" required></textarea>
                                <div class="form-text">Explain why you're a good fit for this position.</div>
                            </div>

                            <div class="mb-3">
                                <label for="resume" class="form-label">Resume (PDF, DOC, DOCX)</label>
                                <input type="file" class="form-control" id="resume" name="resume" accept=".pdf,.doc,.docx">
                                <?php if ($student['resume_path']): ?>
                                    <div class="form-text">You have an existing resume on file. Upload a new one to replace it.</div>
                                <?php endif; ?>
                            </div>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Submit Application</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 