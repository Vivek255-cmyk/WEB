<?php
session_start();
require_once '../config.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    header("Location: ../login.php");
    exit();
}

// Initialize variables
$error = '';
$success = '';
$job = null;
$student = null;
$has_applied = false;

try {
    // Check if job ID is provided
    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        throw new Exception("Invalid job ID.");
    }

    $job_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];

    // Get student profile
    $query = "SELECT * FROM student_profiles WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        throw new Exception("Error preparing student statement: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "i", $user_id);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing student statement: " . mysqli_stmt_error($stmt));
    }

    $result = mysqli_stmt_get_result($stmt);
    $student = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    if (!$student) {
        header("Location: profile.php");
        exit();
    }

    // Get job details
    $query = "SELECT j.*, c.name as company_name, c.industry, c.location as company_location 
              FROM jobs j
              JOIN company_profiles c ON j.company_id = c.id
              WHERE j.id = ? AND j.status = 'active'";
    
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        throw new Exception("Error preparing job statement: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "i", $job_id);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing job statement: " . mysqli_stmt_error($stmt));
    }

    $result = mysqli_stmt_get_result($stmt);
    $job = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    if (!$job) {
        throw new Exception("Job not found or no longer active.");
    }

    // Check if already applied
    $query = "SELECT * FROM applications WHERE job_id = ? AND student_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        throw new Exception("Error preparing application check statement: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "ii", $job_id, $student['id']);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing application check statement: " . mysqli_stmt_error($stmt));
    }

    $result = mysqli_stmt_get_result($stmt);
    $has_applied = mysqli_fetch_assoc($result) ? true : false;
    mysqli_stmt_close($stmt);

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && !$has_applied) {
        $cover_letter = trim($_POST['cover_letter'] ?? '');
        
        if (empty($cover_letter)) {
            throw new Exception("Please provide a cover letter.");
        }

        // Handle resume upload
        if (isset($_FILES['resume']) && $_FILES['resume']['error'] == 0) {
            $allowed_types = ['application/pdf'];
            $max_size = 5 * 1024 * 1024; // 5MB
            
            if (!in_array($_FILES['resume']['type'], $allowed_types)) {
                throw new Exception("Only PDF files are allowed for resume.");
            } elseif ($_FILES['resume']['size'] > $max_size) {
                throw new Exception("Resume file size must be less than 5MB.");
            } else {
                // Create uploads directory if it doesn't exist
                $upload_dir = '../uploads/resumes/';
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                
                // Generate unique filename
                $file_extension = pathinfo($_FILES['resume']['name'], PATHINFO_EXTENSION);
                $filename = 'resume_' . $student['id'] . '_' . time() . '.' . $file_extension;
                $filepath = $upload_dir . $filename;
                
                if (move_uploaded_file($_FILES['resume']['tmp_name'], $filepath)) {
                    $resume_path = 'uploads/resumes/' . $filename;
                    
                    // Update student profile with new resume
                    $update_query = "UPDATE student_profiles SET resume = ? WHERE id = ?";
                    $update_stmt = mysqli_prepare($conn, $update_query);
                    if (!$update_stmt) {
                        throw new Exception("Error preparing resume update statement: " . mysqli_error($conn));
                    }
                    
                    mysqli_stmt_bind_param($update_stmt, "si", $resume_path, $student['id']);
                    if (!mysqli_stmt_execute($update_stmt)) {
                        throw new Exception("Error updating resume: " . mysqli_stmt_error($update_stmt));
                    }
                    mysqli_stmt_close($update_stmt);
                } else {
                    throw new Exception("Error uploading resume file.");
                }
            }
        }

        // Begin transaction
        mysqli_begin_transaction($conn);

        try {
            // Insert application
            $query = "INSERT INTO applications (student_id, job_id, cover_letter, status, apply_date) 
                     VALUES (?, ?, ?, 'pending', NOW())";
            
            $stmt = mysqli_prepare($conn, $query);
            if (!$stmt) {
                throw new Exception("Error preparing application statement: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param($stmt, "iis", $student['id'], $job_id, $cover_letter);
            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception("Error submitting application: " . mysqli_stmt_error($stmt));
            }
            mysqli_stmt_close($stmt);

            mysqli_commit($conn);
            $success = "Your application has been submitted successfully!";
            $has_applied = true;

        } catch (Exception $e) {
            mysqli_rollback($conn);
            throw $e;
        }
    }

} catch (Exception $e) {
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for Job - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .navbar {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
        }
        .job-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .application-form {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            padding: 2rem;
            margin-top: 2rem;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="../index.php">Job Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search_jobs.php">Search Jobs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="my_applications.php">My Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($error); ?>
                <br>
                <a href="search_jobs.php" class="alert-link">Back to Job Search</a>
            </div>
        <?php elseif ($success): ?>
            <div class="alert alert-success" role="alert">
                <?php echo htmlspecialchars($success); ?>
                <br>
                <a href="my_applications.php" class="alert-link">View My Applications</a>
            </div>
        <?php else: ?>
            <div class="job-card p-4">
                <h3><?php echo htmlspecialchars($job['title']); ?></h3>
                <div class="company-info mb-4">
                    <h5 class="text-muted"><?php echo htmlspecialchars($job['company_name']); ?></h5>
                    <p class="mb-2">
                        <i class="fas fa-industry me-2"></i><?php echo htmlspecialchars($job['industry']); ?>
                    </p>
                    <p class="mb-2">
                        <i class="fas fa-map-marker-alt me-2"></i><?php echo htmlspecialchars($job['location']); ?>
                    </p>
                    <?php if ($job['salary_range']): ?>
                        <p class="mb-2">
                            <i class="fas fa-money-bill-wave me-2"></i><?php echo htmlspecialchars($job['salary_range']); ?>
                        </p>
                    <?php endif; ?>
                    <p class="mb-0">
                        <i class="fas fa-clock me-2"></i>Application Deadline: 
                        <?php echo $job['deadline_date'] ? date('F j, Y', strtotime($job['deadline_date'])) : 'No deadline specified'; ?>
                    </p>
                </div>

                <?php if ($has_applied): ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>You have already applied for this position.
                        <br>
                        <a href="my_applications.php" class="alert-link">View your application status</a>
                    </div>
                <?php else: ?>
                    <div class="application-form">
                        <h4 class="mb-4">Submit Your Application</h4>
                        <form method="POST" action="" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="cover_letter" class="form-label">Cover Letter <span class="text-danger">*</span></label>
                                <textarea class="form-control" id="cover_letter" name="cover_letter" rows="6" required 
                                          placeholder="Explain why you're interested in this position and what makes you a good fit..."></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label for="resume" class="form-label">Upload Resume (PDF only, max 5MB)</label>
                                <div class="input-group">
                                    <input type="file" class="form-control" id="resume" name="resume" accept=".pdf">
                                    <?php if (isset($student['resume'])): ?>
                                        <a href="../<?php echo htmlspecialchars($student['resume']); ?>" 
                                           class="btn btn-outline-secondary" 
                                           target="_blank">
                                            <i class="fas fa-file-pdf me-2"></i>View Current Resume
                                        </a>
                                    <?php endif; ?>
                                </div>
                                <div class="form-text">
                                    <?php if (isset($student['resume'])): ?>
                                        You already have a resume on file. Upload a new one to replace it, or leave empty to use the existing one.
                                    <?php else: ?>
                                        Upload your resume in PDF format.
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane me-2"></i>Submit Application
                                </button>
                                <a href="../view_job.php?id=<?php echo $job_id; ?>" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left me-2"></i>Back to Job Details
                                </a>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 