<?php
session_start();
require_once '../config.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    header("Location: ../login.php");
    exit();
}

// Initialize variables
$applications = [];
$error = '';

try {
    // Get student profile ID first
    $query = "SELECT id FROM student_profiles WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        throw new Exception("Error preparing student profile statement: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing student profile statement: " . mysqli_stmt_error($stmt));
    }

    $result = mysqli_stmt_get_result($stmt);
    $student = mysqli_fetch_assoc($result);

    if (!$student) {
        header("Location: profile.php");
        exit();
    }

    // Get all applications with job and company details
    $query = "SELECT a.*, j.title as job_title, j.location, j.salary_range, j.job_type,
                     j.deadline_date, c.name as company_name, c.industry
              FROM applications a
              JOIN jobs j ON a.job_id = j.id
              JOIN company_profiles c ON j.company_id = c.id
              WHERE a.student_id = ?
              ORDER BY a.apply_date DESC";

    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        throw new Exception("Error preparing applications statement: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "i", $student['id']);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing applications statement: " . mysqli_stmt_error($stmt));
    }

    $result = mysqli_stmt_get_result($stmt);
    while ($application = mysqli_fetch_assoc($result)) {
        $applications[] = $application;
    }

} catch (Exception $e) {
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Applications - Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .navbar {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
        }
        .application-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        .application-card:hover {
            transform: translateY(-5px);
        }
        .status-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 500;
        }
        .status-pending {
            background-color: #ffc107;
            color: #000;
        }
        .status-accepted {
            background-color: #198754;
            color: #fff;
        }
        .status-rejected {
            background-color: #dc3545;
            color: #fff;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="../index.php">Job Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search_jobs.php">Search Jobs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="my_applications.php">My Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <h2 class="mb-4">My Applications</h2>
        
        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php elseif (empty($applications)): ?>
            <div class="alert alert-info" role="alert">
                <i class="fas fa-info-circle me-2"></i>You haven't applied to any jobs yet.
                <br>
                <a href="search_jobs.php" class="alert-link">Browse available jobs</a> to start applying!
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($applications as $application): ?>
                    <div class="col-md-6 mb-4">
                        <div class="application-card p-4">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div>
                                    <h5 class="mb-1"><?php echo htmlspecialchars($application['job_title']); ?></h5>
                                    <h6 class="text-muted"><?php echo htmlspecialchars($application['company_name']); ?></h6>
                                </div>
                                <span class="badge status-badge status-<?php echo $application['status']; ?>">
                                    <?php echo ucfirst(htmlspecialchars($application['status'])); ?>
                                </span>
                            </div>
                            
                            <div class="mb-3">
                                <p class="text-muted mb-2">
                                    <i class="fas fa-building me-2"></i><?php echo htmlspecialchars($application['industry']); ?>
                                </p>
                                <p class="text-muted mb-2">
                                    <i class="fas fa-map-marker-alt me-2"></i><?php echo htmlspecialchars($application['location']); ?>
                                </p>
                                <?php if ($application['job_type']): ?>
                                    <p class="text-muted mb-2">
                                        <i class="fas fa-briefcase me-2"></i><?php echo htmlspecialchars($application['job_type']); ?>
                                    </p>
                                <?php endif; ?>
                                <?php if ($application['salary_range']): ?>
                                    <p class="text-muted mb-2">
                                        <i class="fas fa-money-bill-wave me-2"></i><?php echo htmlspecialchars($application['salary_range']); ?>
                                    </p>
                                <?php endif; ?>
                            </div>

                            <div class="d-flex justify-content-between align-items-center text-muted">
                                <div>
                                    <i class="fas fa-clock me-2"></i>Applied: 
                                    <?php echo date('M d, Y', strtotime($application['apply_date'])); ?>
                                </div>
                                <?php if ($application['deadline_date']): ?>
                                    <div>
                                        <i class="fas fa-calendar me-2"></i>Deadline: 
                                        <?php echo date('M d, Y', strtotime($application['deadline_date'])); ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if ($application['status'] === 'accepted'): ?>
                                <div class="alert alert-success mt-3 mb-0">
                                    <i class="fas fa-check-circle me-2"></i>Congratulations! Your application has been accepted.
                                    <br>
                                    Please check your email for further instructions.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 