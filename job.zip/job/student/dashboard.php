<?php
session_start();
require_once '../config.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    header("Location: ../index.php");
    exit();
}

// Check database connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get student profile
$query = "SELECT * FROM student_profiles WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $query);

if (!$stmt) {
    die("Error preparing statement: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
if (!mysqli_stmt_execute($stmt)) {
    die("Error executing statement: " . mysqli_stmt_error($stmt));
}

$result = mysqli_stmt_get_result($stmt);
$student = mysqli_fetch_assoc($result);

if (!$student) {
    die("Student profile not found. Please complete your profile first.");
}

// Get recent applications with error handling
$applications_result = null;
try {
    $applications_query = "SELECT a.id, a.job_id, a.status, a.apply_date, 
                          j.title as job_title, 
                          c.name as company_name 
                          FROM applications a 
                          LEFT JOIN jobs j ON a.job_id = j.id 
                          LEFT JOIN company_profiles c ON j.company_id = c.id 
                          WHERE a.student_id = ? 
                          ORDER BY a.apply_date DESC 
                          LIMIT 5";
    
    $stmt = mysqli_prepare($conn, $applications_query);
    if (!$stmt) {
        throw new Exception("Error preparing applications query: " . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($stmt, "i", $student['id']);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing applications query: " . mysqli_stmt_error($stmt));
    }
    
    $applications_result = mysqli_stmt_get_result($stmt);
} catch (Exception $e) {
    // Log the error but don't stop execution
    error_log($e->getMessage());
    $applications_result = null;
}

// Get recommended jobs with error handling
$recommended_jobs_result = null;
try {
    $recommended_query = "SELECT j.id, j.title, j.post_date, 
                         c.name as company_name 
                         FROM jobs j 
                         LEFT JOIN company_profiles c ON j.company_id = c.id 
                         WHERE j.status = 'active' 
                         AND (j.required_skills LIKE ? OR j.required_course LIKE ?)
                         ORDER BY j.post_date DESC 
                         LIMIT 5";
    
    $stmt = mysqli_prepare($conn, $recommended_query);
    if (!$stmt) {
        throw new Exception("Error preparing recommended jobs query: " . mysqli_error($conn));
    }
    
    $skills_pattern = "%" . $student['skills'] . "%";
    $course_pattern = "%" . $student['course'] . "%";
    mysqli_stmt_bind_param($stmt, "ss", $skills_pattern, $course_pattern);
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing recommended jobs query: " . mysqli_stmt_error($stmt));
    }
    
    $recommended_jobs_result = mysqli_stmt_get_result($stmt);
} catch (Exception $e) {
    // Log the error but don't stop execution
    error_log($e->getMessage());
    $recommended_jobs_result = null;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .navbar {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .profile-header {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
            color: white;
            border-radius: 15px 15px 0 0;
            padding: 20px;
        }
        .badge-pending {
            background: linear-gradient(135deg, #ffc107 0%, #ffb300 100%);
        }
        .badge-accepted {
            background: linear-gradient(135deg, #198754 0%, #146c43 100%);
        }
        .badge-rejected {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
        }
        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .stats-icon {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        .stats-number {
            font-size: 2rem;
            font-weight: bold;
        }
        .stats-label {
            color: #6c757d;
        }
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .action-btn {
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            color: white;
            text-decoration: none;
            transition: transform 0.3s ease;
        }
        .action-btn:hover {
            transform: translateY(-3px);
            color: white;
        }
        .search-jobs {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
        }
        .view-applications {
            background: linear-gradient(135deg, #198754 0%, #146c43 100%);
        }
        .update-profile {
            background: linear-gradient(135deg, #6f42c1 0%, #5a32a3 100%);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Job Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search_jobs.php">Search Jobs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="my_applications.php">My Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- Welcome Section -->
        <div class="row mb-4">
            <div class="col-md-8">
                <div class="card">
                    <div class="profile-header">
                        <h3>Welcome, <?php echo htmlspecialchars($student['full_name']); ?>!</h3>
                        <p class="mb-0"><?php echo htmlspecialchars($student['course']); ?> - Class of <?php echo htmlspecialchars($student['graduation_year']); ?></p>
                    </div>
                    <div class="card-body">
                        <h5>Your Skills</h5>
                        <div class="d-flex flex-wrap gap-2">
                            <?php 
                            $skills = explode(',', $student['skills']);
                            foreach ($skills as $skill): 
                            ?>
                                <span class="badge bg-primary"><?php echo htmlspecialchars(trim($skill)); ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stats-card">
                    <i class="fas fa-briefcase stats-icon text-primary"></i>
                    <div class="stats-number"><?php echo $applications_result ? mysqli_num_rows($applications_result) : 0; ?></div>
                    <div class="stats-label">Total Applications</div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <a href="search_jobs.php" class="action-btn search-jobs">
                <i class="fas fa-search me-2"></i>Search Jobs
            </a>
            <a href="my_applications.php" class="action-btn view-applications">
                <i class="fas fa-file-alt me-2"></i>View Applications
            </a>
            <a href="profile.php" class="action-btn update-profile">
                <i class="fas fa-user-edit me-2"></i>Update Profile
            </a>
        </div>

        <!-- Recommended Jobs -->
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Recommended Jobs</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($recommended_jobs_result && mysqli_num_rows($recommended_jobs_result) > 0): ?>
                            <?php while ($job = mysqli_fetch_assoc($recommended_jobs_result)): ?>
                                <div class="mb-3">
                                    <h6><?php echo htmlspecialchars($job['title']); ?></h6>
                                    <p class="mb-1"><?php echo htmlspecialchars($job['company_name']); ?></p>
                                    <small class="text-muted">Posted: <?php echo date('M d, Y', strtotime($job['post_date'])); ?></small>
                                    <a href="job_details.php?id=<?php echo $job['id']; ?>" class="btn btn-sm btn-primary float-end">View Details</a>
                                </div>
                                <hr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="text-muted">No recommended jobs found based on your profile.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Recent Applications -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Recent Applications</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($applications_result && mysqli_num_rows($applications_result) > 0): ?>
                            <?php while ($application = mysqli_fetch_assoc($applications_result)): ?>
                                <div class="mb-3">
                                    <h6><?php echo htmlspecialchars($application['job_title']); ?></h6>
                                    <p class="mb-1"><?php echo htmlspecialchars($application['company_name']); ?></p>
                                    <span class="badge rounded-pill <?php 
                                        echo $application['status'] == 'pending' ? 'badge-pending' : 
                                            ($application['status'] == 'accepted' ? 'badge-accepted' : 'badge-rejected'); 
                                    ?>">
                                        <?php echo ucfirst(htmlspecialchars($application['status'])); ?>
                                    </span>
                                    <small class="text-muted d-block">Applied: <?php echo date('M d, Y', strtotime($application['apply_date'])); ?></small>
                                </div>
                                <hr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="text-muted">No recent applications found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 