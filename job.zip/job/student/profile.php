<?php
session_start();
require_once '../config.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Get existing profile if it exists
$profile = null;
$query = "SELECT * FROM student_profiles WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
if ($result && mysqli_num_rows($result) > 0) {
    $profile = mysqli_fetch_assoc($result);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = trim($_POST['full_name']);
    $course = trim($_POST['course']);
    $graduation_year = trim($_POST['graduation_year']);
    $skills = trim($_POST['skills']);
    $resume = '';

    // Validate input
    if (empty($full_name) || empty($course) || empty($graduation_year)) {
        $error = "Please fill in all required fields.";
    } else {
        try {
            // Handle file upload
            if (isset($_FILES['resume']) && $_FILES['resume']['error'] == 0) {
                $allowed = ['pdf', 'doc', 'docx'];
                $filename = $_FILES['resume']['name'];
                $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
                
                if (!in_array($ext, $allowed)) {
                    throw new Exception("Only PDF, DOC, and DOCX files are allowed.");
                }

                $resume = 'uploads/resumes/' . uniqid() . '.' . $ext;
                if (!move_uploaded_file($_FILES['resume']['tmp_name'], '../' . $resume)) {
                    throw new Exception("Failed to upload resume.");
                }
            }

            if ($profile) {
                // Update existing profile
                $query = "UPDATE student_profiles SET 
                         full_name = ?, course = ?, graduation_year = ?, 
                         skills = ?" . ($resume ? ", resume = ?" : "") . "
                         WHERE user_id = ?";
                
                $stmt = mysqli_prepare($conn, $query);
                if ($resume) {
                    mysqli_stmt_bind_param($stmt, "sssssi", $full_name, $course, $graduation_year, $skills, $resume, $user_id);
                } else {
                    mysqli_stmt_bind_param($stmt, "ssssi", $full_name, $course, $graduation_year, $skills, $user_id);
                }
            } else {
                // Create new profile
                $query = "INSERT INTO student_profiles (user_id, full_name, course, graduation_year, skills" . ($resume ? ", resume" : "") . ") 
                         VALUES (?, ?, ?, ?, ?" . ($resume ? ", ?" : "") . ")";
                
                $stmt = mysqli_prepare($conn, $query);
                if ($resume) {
                    mysqli_stmt_bind_param($stmt, "isssss", $user_id, $full_name, $course, $graduation_year, $skills, $resume);
                } else {
                    mysqli_stmt_bind_param($stmt, "issss", $user_id, $full_name, $course, $graduation_year, $skills);
                }
            }

            if (mysqli_stmt_execute($stmt)) {
                $success = "Profile " . ($profile ? "updated" : "created") . " successfully!";
                // Refresh profile data
                $query = "SELECT * FROM student_profiles WHERE user_id = ?";
                $stmt = mysqli_prepare($conn, $query);
                mysqli_stmt_bind_param($stmt, "i", $user_id);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                $profile = mysqli_fetch_assoc($result);
            } else {
                throw new Exception("Error saving profile: " . mysqli_error($conn));
            }
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $profile ? 'Edit' : 'Create'; ?> Profile - Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .navbar {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
        }
        .profile-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .form-control:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
        }
        .btn-primary {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            transition: transform 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-3px);
        }
        .skill-tag {
            background: #e9ecef;
            border-radius: 20px;
            padding: 5px 10px;
            margin: 2px;
            display: inline-block;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Job Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="profile.php">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search_jobs.php">Search Jobs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="applications.php">My Applications</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="profile-card p-4">
                    <h3 class="mb-4"><?php echo $profile ? 'Edit' : 'Create'; ?> Your Profile</h3>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo htmlspecialchars($success); ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="full_name" class="form-label">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="full_name" name="full_name" 
                                   value="<?php echo htmlspecialchars($profile['full_name'] ?? ''); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="course" class="form-label">Course <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="course" name="course" 
                                   value="<?php echo htmlspecialchars($profile['course'] ?? ''); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="graduation_year" class="form-label">Graduation Year <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="graduation_year" name="graduation_year" 
                                   value="<?php echo htmlspecialchars($profile['graduation_year'] ?? ''); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="skills" class="form-label">Skills (comma-separated)</label>
                            <input type="text" class="form-control" id="skills" name="skills" 
                                   value="<?php echo htmlspecialchars($profile['skills'] ?? ''); ?>">
                            <div class="form-text">Example: PHP, MySQL, JavaScript, HTML, CSS</div>
                        </div>

                        <div class="mb-3">
                            <label for="resume" class="form-label">Resume</label>
                            <input type="file" class="form-control" id="resume" name="resume" accept=".pdf,.doc,.docx">
                            <?php if (!empty($profile['resume'])): ?>
                                <div class="mt-2">
                                    <a href="../<?php echo htmlspecialchars($profile['resume']); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-file-alt me-1"></i>View Current Resume
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">
                                <?php echo $profile ? 'Update Profile' : 'Create Profile'; ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 