<?php
session_start();
require_once '../config.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    header("Location: ../login.php");
    exit();
}

// Get search parameters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$location = isset($_GET['location']) ? trim($_GET['location']) : '';
$course = isset($_GET['course']) ? trim($_GET['course']) : '';
$skills = isset($_GET['skills']) ? trim($_GET['skills']) : '';

// Build the query
$query = "SELECT j.*, c.name as company_name 
          FROM jobs j 
          JOIN company_profiles c ON j.company_id = c.id 
          WHERE j.status = 'active'";

$params = [];
$types = "";

if (!empty($search)) {
    $query .= " AND (j.title LIKE ? OR j.description LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "ss";
}

if (!empty($location)) {
    $query .= " AND j.location LIKE ?";
    $location_param = "%$location%";
    $params[] = $location_param;
    $types .= "s";
}

if (!empty($course)) {
    $query .= " AND j.required_course LIKE ?";
    $course_param = "%$course%";
    $params[] = $course_param;
    $types .= "s";
}

if (!empty($skills)) {
    $query .= " AND j.required_skills LIKE ?";
    $skills_param = "%$skills%";
    $params[] = $skills_param;
    $types .= "s";
}

$query .= " ORDER BY j.post_date DESC";

// Initialize variables
$jobs = [];
$error = '';

try {
    // Prepare and execute the query
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        throw new Exception("Error preparing statement: " . mysqli_error($conn));
    }

    if (!empty($params)) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }

    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing statement: " . mysqli_stmt_error($stmt));
    }

    $result = mysqli_stmt_get_result($stmt);
    
    // Fetch all jobs
    while ($job = mysqli_fetch_assoc($result)) {
        $jobs[] = $job;
    }

} catch (Exception $e) {
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Jobs - Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .navbar {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
        }
        .search-form {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            padding: 2rem;
            margin-bottom: 2rem;
        }
        .job-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .job-card:hover {
            transform: translateY(-5px);
        }
        .search-btn {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            color: white;
            transition: transform 0.3s ease;
        }
        .search-btn:hover {
            transform: translateY(-2px);
            color: white;
        }
        .badge-custom {
            font-size: 0.8rem;
            padding: 0.5rem 1rem;
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="../index.php">Job Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="search_jobs.php">Search Jobs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="my_applications.php">My Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="search-form">
            <h4 class="mb-4">Search Jobs</h4>
            <form method="GET" class="row g-3">
                <div class="col-md-6">
                    <label for="search" class="form-label">Search</label>
                    <input type="text" class="form-control" id="search" name="search" 
                           placeholder="Job title or description" value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-6">
                    <label for="location" class="form-label">Location</label>
                    <input type="text" class="form-control" id="location" name="location" 
                           placeholder="City or country" value="<?php echo htmlspecialchars($location); ?>">
                </div>
                <div class="col-md-6">
                    <label for="course" class="form-label">Required Course</label>
                    <input type="text" class="form-control" id="course" name="course" 
                           placeholder="Course name" value="<?php echo htmlspecialchars($course); ?>">
                </div>
                <div class="col-md-6">
                    <label for="skills" class="form-label">Required Skills</label>
                    <input type="text" class="form-control" id="skills" name="skills" 
                           placeholder="Skills" value="<?php echo htmlspecialchars($skills); ?>">
                </div>
                <div class="col-12">
                    <button type="submit" class="btn search-btn">
                        <i class="fas fa-search me-2"></i>Search Jobs
                    </button>
                </div>
            </form>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php elseif (empty($jobs)): ?>
            <div class="alert alert-info" role="alert">
                <i class="fas fa-info-circle me-2"></i>No jobs found matching your criteria.
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($jobs as $job): ?>
                    <div class="col-md-6 mb-4">
                        <div class="job-card p-4">
                            <h5 class="mb-3"><?php echo htmlspecialchars($job['title']); ?></h5>
                            <div class="mb-3">
                                <p class="text-muted mb-2">
                                    <i class="fas fa-building me-2"></i><?php echo htmlspecialchars($job['company_name']); ?>
                                </p>
                                <p class="text-muted mb-2">
                                    <i class="fas fa-map-marker-alt me-2"></i><?php echo htmlspecialchars($job['location']); ?>
                                </p>
                                <?php if ($job['salary_range']): ?>
                                    <p class="text-muted mb-2">
                                        <i class="fas fa-money-bill-wave me-2"></i><?php echo htmlspecialchars($job['salary_range']); ?>
                                    </p>
                                <?php endif; ?>
                                <?php if ($job['required_course']): ?>
                                    <p class="text-muted mb-2">
                                        <i class="fas fa-graduation-cap me-2"></i><?php echo htmlspecialchars($job['required_course']); ?>
                                    </p>
                                <?php endif; ?>
                                <p class="text-muted mb-0">
                                    <i class="fas fa-clock me-2"></i>Posted: <?php echo date('M d, Y', strtotime($job['post_date'])); ?>
                                </p>
                            </div>
                            <div class="d-grid">
                                <a href="apply_job.php?id=<?php echo $job['id']; ?>" class="btn btn-primary">
                                    <i class="fas fa-paper-plane me-2"></i>Apply Now
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 