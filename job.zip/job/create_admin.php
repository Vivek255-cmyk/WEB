<?php
require_once 'config.php';

// Check database connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Admin credentials
$username = "admin";
$email = "admin@jobportal.com";
$password = "admin123"; // You should change this password after first login
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Check if admin already exists
$check_query = "SELECT * FROM users WHERE username = ? AND user_type = 'admin'";
$stmt = mysqli_prepare($conn, $check_query);
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    echo "Admin user already exists!";
} else {
    // Insert admin user
    $insert_query = "INSERT INTO users (username, email, password, user_type) VALUES (?, ?, ?, 'admin')";
    $stmt = mysqli_prepare($conn, $insert_query);
    mysqli_stmt_bind_param($stmt, "sss", $username, $email, $hashed_password);
    
    if (mysqli_stmt_execute($stmt)) {
        echo "Admin user created successfully!<br>";
        echo "Username: " . $username . "<br>";
        echo "Password: " . $password . "<br>";
        echo "Please change the password after first login.";
    } else {
        echo "Error creating admin user: " . mysqli_error($conn);
    }
}
?> 