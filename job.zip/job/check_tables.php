<?php
require_once 'config.php';

// Check database connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if tables exist
$tables = ['users', 'company_profiles', 'student_profiles', 'jobs', 'applications', 'interviews'];
$missing_tables = [];

foreach ($tables as $table) {
    $result = mysqli_query($conn, "SHOW TABLES LIKE '$table'");
    if (mysqli_num_rows($result) == 0) {
        $missing_tables[] = $table;
    }
}

if (!empty($missing_tables)) {
    echo "<h2>Missing Tables:</h2>";
    echo "<ul>";
    foreach ($missing_tables as $table) {
        echo "<li>$table</li>";
    }
    echo "</ul>";
} else {
    echo "<h2>All tables exist!</h2>";
}

// Show table structures
echo "<h2>Table Structures:</h2>";
foreach ($tables as $table) {
    echo "<h3>$table</h3>";
    $result = mysqli_query($conn, "DESCRIBE $table");
    if ($result) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['Field'] . "</td>";
            echo "<td>" . $row['Type'] . "</td>";
            echo "<td>" . $row['Null'] . "</td>";
            echo "<td>" . $row['Key'] . "</td>";
            echo "<td>" . $row['Default'] . "</td>";
            echo "<td>" . $row['Extra'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>Error describing table: " . mysqli_error($conn) . "</p>";
    }
}

// Check for sample data
echo "<h2>Sample Data Check:</h2>";
$tables_to_check = ['student_profiles', 'jobs', 'applications'];
foreach ($tables_to_check as $table) {
    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM $table");
    $row = mysqli_fetch_assoc($result);
    echo "<p>$table: " . $row['count'] . " records</p>";
}
?> 